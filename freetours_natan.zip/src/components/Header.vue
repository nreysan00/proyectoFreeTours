<script setup>
import router from "@/router";
import {ref} from "vue"

const emit = defineEmits(["sesionCerrada"]);

const props= defineProps({
  title: String,
  usuarioAutenticado: Object
});




function cerrarSesion() {
  
  
  emit("sesionCerrada");
  router.push({name:"home"});



}
</script>


<template>
    <header class="bg-success text-white  p-3">
      <div class="row">
        <h1 class="col-8">{{ title }}</h1>
        <div class="col-4">
        
        <div v-if="usuarioAutenticado" class="container text-end">
          <!-- se deberia mostrar con usuarioAuntenticado.user.nombre y usuarioAuntenticado.user.rol-->
          <span>Bienvenido, {{ usuarioAutenticado.nombre }}</span>
          <button @click.prevent="cerrarSesion" class="btn btn-danger">Cerrar Sesión</button>
          
        </div>
      </div>
      </div>
  </header>
</template>
  
 
<style scoped>

</style>
  